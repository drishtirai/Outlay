package com.hp.ali.ecomerceapp.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hp.ali.ecomerceapp.R;
import com.hp.ali.ecomerceapp.activities.CartActivity;
import com.hp.ali.ecomerceapp.login.LogInActivity;
import com.yarolegovich.slidingrootnav.SlidingRootNav;

import static maes.tech.intentanim.CustomIntent.customType;

public class MainFragment extends Fragment {
    ImageView img_home,img_wishlist,img_setting,img_profile;
    ImageButton menu_btn;
    Fragment fragmentClass = new HomeFragment();
    FloatingActionButton btn_cart;



    public MainFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_main, container, false);

        btn_cart =  v.findViewById(R.id.btn_cart);
        btn_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(getContext(), CartActivity.class);
                startActivity(intent);
                customType(getContext(),"left-to-right");

            }
        });



        img_home =  v.findViewById(R.id.img_home);
        img_wishlist =  v.findViewById(R.id.img_wishlist);
        img_setting =  v.findViewById(R.id.img_setting);
        img_profile =  v.findViewById(R.id.img_profile);


        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.home_fragment, fragmentClass)
                .commit();
        img_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragmentClass = new HomeFragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.home_fragment, fragmentClass)
                        .commit();


            }
        });
        img_wishlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragmentClass = new WishFragment();

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.home_fragment, fragmentClass)
                        .commit();

            }
        });
        img_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragmentClass = new SettingFragment();

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.home_fragment, fragmentClass)
                        .commit();

            }
        });
        img_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragmentClass = new ProfileFragment();

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.home_fragment, fragmentClass)
                        .commit();

            }
        });
        return v;
    }
}