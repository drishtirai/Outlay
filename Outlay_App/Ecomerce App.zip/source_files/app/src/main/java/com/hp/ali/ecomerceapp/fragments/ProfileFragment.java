package com.hp.ali.ecomerceapp.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import de.hdodenhof.circleimageview.CircleImageView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hp.ali.ecomerceapp.R;
import com.hp.ali.ecomerceapp.activities.MainActivity;


public class ProfileFragment extends Fragment {
CircleImageView profile_image;



    public ProfileFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.fragment_profile, container, false);
        profile_image =  v.findViewById(R.id.profile_image);
        profile_image.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.dp));
        ((MainActivity)getActivity()).top_toolbar.setVisibility(View.GONE);
        return v;
    }
}