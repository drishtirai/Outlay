package com.hp.ali.ecomerceapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hp.ali.ecomerceapp.R;
import com.hp.ali.ecomerceapp.fragments.HomeFragment;
import com.hp.ali.ecomerceapp.fragments.MainFragment;
import com.yarolegovich.slidingrootnav.SlidingRootNav;
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder;

import static android.view.View.GONE;


public class MainActivity extends AppCompatActivity {
    Fragment fragmentClass = new MainFragment();
    SlidingRootNav slidingRootNav;
    ImageButton menu_btn;
    Context context;
    Boolean isOpened = false;
   public LinearLayout top_toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        top_toolbar =  findViewById(R.id.top_toolbar);
        context = getApplicationContext();









        menu_btn =  findViewById(R.id.menu_btn);


        slidingRootNav =  new SlidingRootNavBuilder(this)
                .withMenuLayout(R.layout.menu_left_drawer)
                .inject();

        menu_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isOpened) {
                    slidingRootNav.closeMenu();
                    isOpened = true;
                } else {
                    slidingRootNav.openMenu();
                }
            }
        });

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_fragment, fragmentClass)
                .commit();


    }

}