package com.hp.ali.ecomerceapp.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import de.hdodenhof.circleimageview.CircleImageView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hp.ali.ecomerceapp.R;
import com.hp.ali.ecomerceapp.activities.MainActivity;


public class SettingFragment extends Fragment {



    public SettingFragment() {
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_setting, container, false);



        ((MainActivity)getActivity()).top_toolbar.setVisibility(View.GONE);
        return view;

    }
}