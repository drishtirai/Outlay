package com.hp.ali.ecomerceapp.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Switch;

import com.hp.ali.ecomerceapp.R;

public class RegisterActivity extends AppCompatActivity {
    Switch simpleSwitch,simpleSwitch1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        simpleSwitch  = (Switch) findViewById(R.id.simpleSwitch);
        simpleSwitch1  = (Switch) findViewById(R.id.simpleSwitch1);

    }
}