package com.hp.ali.ecomerceapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.hp.ali.ecomerceapp.R;
import com.hp.ali.ecomerceapp.models.MyListData;

public class CheckoutActivity extends AppCompatActivity {
    MyListData[] midListData;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        midListData  = new MyListData[]{
                new MyListData("sofa", R.drawable.sofa1),
                new MyListData("sofa1",R.drawable.sofa1),
                new MyListData("sofa_1", R.drawable.sofa_1),
                new MyListData("bag", R.drawable.sofa_1),
                new MyListData("makeup",R.drawable.sofa_1),
                new MyListData("bike", R.drawable.sofa_1),
                new MyListData("ifone",R.drawable.sofa_1),
        };

    }

}