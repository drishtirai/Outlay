import React, { useEffect } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import Product from "../components/Product";
import LoadingBox from "../components/LoadingBox";
import MessageBox from "../components/MessageBox";
import { useDispatch, useSelector } from "react-redux";
import { listProducts } from "../actions/productActions";
import { listTopSellers } from "../actions/userActions";
import { Link } from "react-router-dom";

export default function HomeScreen() {
  const dispatch = useDispatch();
  const productList = useSelector((state) => state.productList);
  const { loading, error, products } = productList;

  const userTopSellersList = useSelector((state) => state.userTopSellersList);
  const {
    loading: loadingSellers,
    error: errorSellers,
    users: sellers,
  } = userTopSellersList;

  useEffect(() => {
    dispatch(listProducts({}));
    dispatch(listTopSellers());
  }, [dispatch]);
  return (
    <div className="homescreen-body-container">
      <h2 className="top-sellers-heading">Top Sellers</h2>
      {loadingSellers ? (
        <LoadingBox></LoadingBox>
      ) : errorSellers ? (
        <MessageBox variant="danger">{errorSellers}</MessageBox>
      ) : (
        <>
          {sellers.length === 0 && <MessageBox>No Seller Found</MessageBox>}
          <Carousel showArrows autoPlay showThumbs={false}>
            {sellers.map((seller) => (
              <div key={seller._id} className="top-selling">
                <img src={seller.seller.logo} alt={seller.seller.name} />
                <span className="legend">Top Selling</span>
              </div>
            ))}
          </Carousel>
        </>
      )}
      <h2 className="top-sellers-heading">Featured Products</h2>
      {loading ? (
        <LoadingBox></LoadingBox>
      ) : error ? (
        <MessageBox variant="danger">{error}</MessageBox>
      ) : (
        <>
          {products.length === 0 && <MessageBox>No Product Found</MessageBox>}
          <div className="row center">
            {products.map((product) => (
              <Product key={product._id} product={product}></Product>
            ))}
          </div>
        </>
      )}
      <div>
        <h2 className="top-sellers-heading">Services Offered</h2>
        <div className="services-provided-container">
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">
                  <i className="fa fa-truck" width="20px" height="20px"></i>
                  &nbsp;&nbsp;Delivery
                </h5>
                <p className="card-text">
                  Can't reach to stores ? We deliver to your doorstep.
                  <br />
                </p>
                <span className="btn btn-primary">Learn More</span>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">
                  <i className="fa fa-credit-card"></i>
                  &nbsp;&nbsp; Payment
                </h5>
                <p className="card-text">We accept all major credit cards.</p>
                <br />
                <span className="btn btn-primary">Learn More</span>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">
                  <i className="fa fa-phone"></i>
                  &nbsp;&nbsp; Contact Us
                </h5>
                <p className="card-text">Feel free to contact us.</p>
                <br />
                <span className="btn btn-primary">Learn More</span>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">
                  <i className="fa fa-question-circle"></i>
                  &nbsp;&nbsp; Help
                </h5>
                <p className="card-text">We are here to help you.</p>
                <br />
                <span className="btn btn-primary">Learn More</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
